class Person:

    def __init__(self, name='Tom'):
        self.name = name


person = Person('John')
print(person.name)
