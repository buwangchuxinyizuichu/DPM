global_dict = {}
